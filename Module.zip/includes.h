#ifndef MODULELAST_INCLUDES_H
#define MODULELAST_INCLUDES_H

#include "iostream"
#include "algorithm"

using namespace std;

#endif //MODULELAST_INCLUDES_H
