#include "task1/MemoryBlock.h"
#include "task1/MemoryManager.h"
#include "task2/Spisok.h"
#include "task3/Order.h"
#include "task3/DeliverySystem.h"

int DeliverySystem::number=0;

int main() {
//task 1
/*
    MemoryManager memoryManager;
    memoryManager.allocateMemory(12);
    memoryManager.allocateMemory(30);
*/

//task2
/*    Spisok obj;
    obj.showMylist();
    obj.showMaxScool();*/

//task 3
/*
    DeliverySystem base;
int main_menu;
do{
    cout <<"Main menu: " << endl;
    cout <<"1. Add order" << endl;
    cout <<"2. Find order" << endl;
    cout <<"3. Show all orders" << endl;
    cout <<"4. Save to file" << endl;
    cout <<"5. Load from file" << endl;
    cout <<"0. Exit" << endl;
    cout <<"Choice: ";
    cin >> main_menu;
    switch (main_menu) {
        case 1:{
            base.addOrderToBase();
            break;
        }
        case 2:{
            base.Search();
            break;
        }
        case 3:{
            base.showAllOrders();
            break;
        }
        case 4:{
            base.saveToFile();
        }
        case 5:{
            base.loadFromFile();
        }
    }

}while(main_menu!=0);
*/


    return 0;
}
